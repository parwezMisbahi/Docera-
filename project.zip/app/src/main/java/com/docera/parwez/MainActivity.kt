package com.docera.parwez

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.InputStream
import java.io.RandomAccessFile

class MainActivity : ComponentActivity() {

    companion object {
        private const val STORAGE_PREFS = "vaultnotes_storage_prefs"
        private const val KEY_FOLDER_URIS = "pdf_folder_tree_uris"
        private const val MAX_FOLDER_DEPTH = 8
        private const val MAX_ENTRIES_PER_FOLDER = 2000
        private const val MAX_TOTAL_ALL_FILES_SCAN = 15000
    }

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // Incoming PDF state
    @Volatile
    private var hasIncomingPdf: Boolean = false
    @Volatile
    private var incomingPdfName: String? = null
    @Volatile
    private var incomingPdfSize: Long = 0L
    @Volatile
    private var incomingPdfError: String? = null
    @Volatile
    private var currentTempFile: File? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris: Array<Uri>? = if (result.resultCode == RESULT_OK && result.data != null) {
            val clipData = result.data?.clipData
            if (clipData != null && clipData.itemCount > 0) {
                Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
            } else {
                result.data?.data?.let { arrayOf(it) }
            }
        } else {
            null
        }
        filePathCallback?.onReceiveValue(uris)
        filePathCallback = null
    }

    private var pendingWebPermission: PermissionRequest? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val req = pendingWebPermission
        pendingWebPermission = null
        if (req != null) {
            val allowed = req.resources.filter { res ->
                when (res) {
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                        result[Manifest.permission.RECORD_AUDIO] == true ||
                            hasPerm(Manifest.permission.RECORD_AUDIO)
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                        result[Manifest.permission.CAMERA] == true ||
                            hasPerm(Manifest.permission.CAMERA)
                    else -> false
                }
            }.toTypedArray()
            try {
                if (allowed.isNotEmpty()) req.grant(allowed) else req.deny()
            } catch (_: Exception) {
            }
        }
    }

    private fun hasPerm(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    // --- Auto-import from device storage: folder picker (Storage Access Framework) ---
    private val folderPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val treeUri = if (result.resultCode == RESULT_OK) result.data?.data else null
        if (treeUri == null) {
            notifyFolderPickResult(false, null)
            return@registerForActivityResult
        }
        try {
            contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // Some providers (or File Managers) don't support persistable permission.
            // We still remember the folder below; it just may need to be re-picked
            // later if the OS revokes temporary access. Never crash here.
        }
        val prefs = getSharedPreferences(STORAGE_PREFS, MODE_PRIVATE)
        val current = (prefs.getStringSet(KEY_FOLDER_URIS, null) ?: emptySet()).toMutableSet()
        current.add(treeUri.toString())
        prefs.edit().putStringSet(KEY_FOLDER_URIS, current).apply()
        notifyFolderPickResult(true, folderDisplayName(treeUri))
    }

    // --- Auto-import from device storage: "All files access" (whole storage scan) ---
    private val allFilesAccessLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ -> notifyAllFilesAccessChanged() }

    private val legacyStoragePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> notifyAllFilesAccessChanged() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Camera / microphone permissions are now requested only when a feature
        // actually needs them (see onPermissionRequest below), not at app start.

        // Process incoming intent (e.g. Open with from File Manager)
        handleIntent(intent)

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                useWideViewPort = true
                loadWithOverviewMode = true
                displayZoomControls = false
                setSupportZoom(true)
                builtInZoomControls = true
                mediaPlaybackRequiresUserGesture = false
                allowFileAccessFromFileURLs = true
                allowUniversalAccessFromFileURLs = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    safeBrowsingEnabled = false
                }
            }

            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (hasIncomingPdf) {
                        view?.evaluateJavascript(
                            "if (typeof window.checkIncomingPdf === 'function') { window.checkIncomingPdf(); }",
                            null
                        )
                    }
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        val needed = mutableListOf<String>()
                        for (res in request.resources) {
                            when (res) {
                                PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                                    if (!hasPerm(Manifest.permission.RECORD_AUDIO)) needed.add(Manifest.permission.RECORD_AUDIO)
                                PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                                    if (!hasPerm(Manifest.permission.CAMERA)) needed.add(Manifest.permission.CAMERA)
                            }
                        }
                        val supported = request.resources.filter {
                            it == PermissionRequest.RESOURCE_AUDIO_CAPTURE ||
                                it == PermissionRequest.RESOURCE_VIDEO_CAPTURE
                        }.toTypedArray()
                        if (supported.isEmpty()) {
                            request.deny()
                        } else if (needed.isEmpty()) {
                            request.grant(supported)
                        } else {
                            pendingWebPermission?.let { try { it.deny() } catch (_: Exception) {} }
                            pendingWebPermission = request
                            permissionLauncher.launch(needed.toTypedArray())
                        }
                    }
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    this@MainActivity.filePathCallback?.onReceiveValue(null)
                    this@MainActivity.filePathCallback = filePathCallback

                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "*/*"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }
                    if (fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }

                    try {
                        filePickerLauncher.launch(intent)
                    } catch (e: Exception) {
                        this@MainActivity.filePathCallback?.onReceiveValue(null)
                        this@MainActivity.filePathCallback = null
                        return false
                    }
                    return true
                }
            }

            // Register bridge for passing incoming PDF data securely into WebView
            addJavascriptInterface(AndroidPdfBridge(), "AndroidPdfBridge")
            // Register bridge for auto-discovering PDFs already on the device (no import/copy needed)
            addJavascriptInterface(AndroidStorageBridge(), "AndroidStorageBridge")
            // Register bridge so the WebView's About screen can open mailto:/wa.me/Play Store
            // links in the user's actual Gmail/WhatsApp/Play Store app — plain <a href> links
            // to these schemes don't leave the WebView on their own since no
            // shouldOverrideUrlLoading is set up (intentionally, so normal in-app navigation
            // is left untouched everywhere else).
            addJavascriptInterface(AndroidLinkBridge(), "AndroidLinkBridge")

            loadUrl("file:///android_asset/index.html")
        }

        setContentView(webView)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onDestroy() {
        try {
            webView.stopLoading()
            webView.removeJavascriptInterface("AndroidPdfBridge")
            webView.removeJavascriptInterface("AndroidStorageBridge")
            webView.removeJavascriptInterface("AndroidLinkBridge")
            (webView.parent as? android.view.ViewGroup)?.removeView(webView)
            webView.destroy()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        if (hasIncomingPdf) {
            webView.evaluateJavascript(
                "if (typeof window.checkIncomingPdf === 'function') { window.checkIncomingPdf(); }",
                null
            )
        }
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        val type = intent.type

        val uri: Uri? = when (action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) ?: intent.data
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(Intent.EXTRA_STREAM) ?: intent.data
                }
            }
            else -> null
        }

        if (uri == null) return

        // Verify if it is a PDF or generic file view intent
        val isPdf = type?.equals("application/pdf", ignoreCase = true) == true ||
                uri.toString().endsWith(".pdf", ignoreCase = true) ||
                uri.lastPathSegment?.endsWith(".pdf", ignoreCase = true) == true ||
                try {
                    contentResolver.getType(uri)?.equals("application/pdf", ignoreCase = true) == true
                } catch (_: Exception) {
                    false
                }

        if (!isPdf && action != Intent.ACTION_VIEW) return

        copyPdfToCache(uri)
    }

    private fun copyPdfToCache(uri: Uri) {
        incomingPdfError = null
        hasIncomingPdf = false

        // Extract display name
        var resolvedName: String? = null
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIdx != -1 && cursor.moveToFirst()) {
                        resolvedName = cursor.getString(nameIdx)
                    }
                }
            } catch (_: Exception) {
                // Ignore cursor query error and fall back
            }
        }
        if (resolvedName.isNullOrBlank()) {
            resolvedName = uri.lastPathSegment?.let { segment ->
                val lastSlash = segment.lastIndexOf('/')
                if (lastSlash != -1) segment.substring(lastSlash + 1) else segment
            }
        }
        if (resolvedName.isNullOrBlank()) {
            resolvedName = "Document.pdf"
        } else if (!resolvedName!!.endsWith(".pdf", ignoreCase = true)) {
            resolvedName = "$resolvedName.pdf"
        }
        incomingPdfName = resolvedName

        // Safely open stream using ContentResolver with permission handling
        try {
            val inputStream: InputStream = try {
                contentResolver.openInputStream(uri)
            } catch (e: Exception) {
                if (uri.scheme == "file" && uri.path != null) {
                    FileInputStream(File(uri.path!!))
                } else {
                    throw e
                }
            } ?: throw FileNotFoundException("Unable to open input stream for: $uri")

            val safePrefix = "open_with_" + System.currentTimeMillis()
            val targetFile = File(cacheDir, "$safePrefix.pdf")

            // Clean up any old temporary open_with_ files
            cacheDir.listFiles()?.forEach { file ->
                if (file.name.startsWith("open_with_") && file.name.endsWith(".pdf")) {
                    file.delete()
                }
            }

            inputStream.use { input ->
                targetFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }

            if (!targetFile.exists() || targetFile.length() == 0L) {
                targetFile.delete()
                incomingPdfError = "The selected PDF file is empty or could not be read."
                hasIncomingPdf = true
                return
            }

            currentTempFile = targetFile
            incomingPdfSize = targetFile.length()
            hasIncomingPdf = true
        } catch (e: SecurityException) {
            incomingPdfError = "Permission denied to read this PDF file."
            hasIncomingPdf = true
        } catch (e: FileNotFoundException) {
            incomingPdfError = "The selected PDF file could not be found or opened."
            hasIncomingPdf = true
        } catch (e: Exception) {
            incomingPdfError = "Failed to open PDF: ${e.localizedMessage ?: "File inaccessible"}"
            hasIncomingPdf = true
        }
    }

    // Opens a mailto:/https:// (WhatsApp, Play Store, etc.) link in the user's real
    // Gmail/WhatsApp/Play Store app, since the WebView itself can't handle those.
    inner class AndroidLinkBridge {
        @JavascriptInterface
        fun openExternal(url: String) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } catch (e: Exception) {
                // No app installed that can handle this link — silently ignore.
            }
        }
    }

    inner class AndroidPdfBridge {
        @JavascriptInterface
        fun hasIncomingPdf(): Boolean {
            return this@MainActivity.hasIncomingPdf
        }

        @JavascriptInterface
        fun getIncomingPdfError(): String? {
            return this@MainActivity.incomingPdfError
        }

        @JavascriptInterface
        fun getIncomingPdfInfo(): String? {
            if (!this@MainActivity.hasIncomingPdf || this@MainActivity.incomingPdfError != null) return null
            val name = this@MainActivity.incomingPdfName ?: "Document.pdf"
            val size = this@MainActivity.incomingPdfSize
            val escapedName = name.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
            return """{"name":"$escapedName","size":$size}"""
        }

        @JavascriptInterface
        fun readPdfChunk(offset: Int, length: Int): String? {
            val file = this@MainActivity.currentTempFile ?: return null
            if (!file.exists() || offset >= file.length() || offset < 0) return null
            return try {
                RandomAccessFile(file, "r").use { raf ->
                    raf.seek(offset.toLong())
                    val remaining = file.length() - offset
                    val toRead = if (remaining < length) remaining.toInt() else length
                    val buffer = ByteArray(toRead)
                    val bytesRead = raf.read(buffer)
                    if (bytesRead > 0) {
                        Base64.encodeToString(buffer, 0, bytesRead, Base64.NO_WRAP)
                    } else {
                        null
                    }
                }
            } catch (_: Exception) {
                null
            }
        }

        @JavascriptInterface
        fun clearIncomingPdf() {
            this@MainActivity.hasIncomingPdf = false
            this@MainActivity.incomingPdfError = null
        }
    }

    // ================= Auto-import from device storage (no manual import needed) =================

    private fun notifyFolderPickResult(success: Boolean, folderName: String?) {
        runOnUiThread {
            val nameArg = if (folderName != null) "\"${jsonEscape(folderName)}\"" else "null"
            webView.evaluateJavascript(
                "if (typeof window.onFolderAdded === 'function') { window.onFolderAdded($success, $nameArg); }",
                null
            )
        }
    }

    private fun notifyAllFilesAccessChanged() {
        val granted = hasAllFilesAccessInternal()
        runOnUiThread {
            webView.evaluateJavascript(
                "if (typeof window.onAllFilesAccessChanged === 'function') { window.onAllFilesAccessChanged($granted); }",
                null
            )
        }
    }

    private fun hasAllFilesAccessInternal(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun folderDisplayName(uri: Uri): String {
        return try {
            val last = uri.lastPathSegment?.let { Uri.decode(it) } ?: return uri.toString()
            val afterColon = last.substringAfterLast(':')
            if (afterColon.isBlank()) last else afterColon
        } catch (_: Exception) {
            uri.toString()
        }
    }

    private fun jsonEscape(s: String): String = s
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r")

    /**
     * Recursively lists PDF files under a Storage Access Framework folder tree,
     * without copying any bytes. [treeRootUri] stays the same across recursive calls
     * (it identifies the granted tree); only [docId] changes as we descend.
     */
    private fun scanTreeForPdfs(
        treeRootUri: Uri,
        docId: String,
        depth: Int,
        emit: (key: String, name: String, size: Long, lastModified: Long, source: String) -> Unit
    ) {
        if (depth > MAX_FOLDER_DEPTH) return
        val childrenUri = try {
            DocumentsContract.buildChildDocumentsUriUsingTree(treeRootUri, docId)
        } catch (_: Exception) {
            return
        }
        try {
            contentResolver.query(
                childrenUri,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED
                ),
                null, null, null
            )?.use { cursor ->
                var count = 0
                while (cursor.moveToNext() && count < MAX_ENTRIES_PER_FOLDER) {
                    count++
                    val childDocId = cursor.getString(0) ?: continue
                    val name = cursor.getString(1) ?: continue
                    val mime = cursor.getString(2) ?: ""
                    val size = if (cursor.isNull(3)) 0L else cursor.getLong(3)
                    val lastMod = if (cursor.isNull(4)) 0L else cursor.getLong(4)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (!name.startsWith(".")) {
                            scanTreeForPdfs(treeRootUri, childDocId, depth + 1, emit)
                        }
                    } else if (mime.equals("application/pdf", ignoreCase = true) ||
                        name.endsWith(".pdf", ignoreCase = true)
                    ) {
                        val docUri = DocumentsContract.buildDocumentUriUsingTree(treeRootUri, childDocId)
                        emit(docUri.toString(), name, size, lastMod, "folder")
                    }
                }
            }
        } catch (_: Exception) {
            // A folder that became inaccessible (revoked permission, unmounted SD card, etc.)
            // is skipped instead of crashing the whole scan.
        }
    }

    inner class AndroidStorageBridge {

        @JavascriptInterface
        fun pickFolder() {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                        addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                        )
                    }
                    folderPickerLauncher.launch(intent)
                } catch (_: Exception) {
                    notifyFolderPickResult(false, null)
                }
            }
        }

        @JavascriptInterface
        fun listFolders(): String {
            val prefs = getSharedPreferences(STORAGE_PREFS, MODE_PRIVATE)
            val uris = prefs.getStringSet(KEY_FOLDER_URIS, null) ?: emptySet()
            val persisted = try {
                contentResolver.persistedUriPermissions
            } catch (_: Exception) {
                emptyList()
            }
            val sb = StringBuilder("[")
            var first = true
            for (u in uris) {
                val uri = try {
                    Uri.parse(u)
                } catch (_: Exception) {
                    continue
                }
                val stillGranted = persisted.any { it.uri == uri && it.isReadPermission }
                if (!stillGranted) continue
                if (!first) sb.append(",")
                first = false
                sb.append("{\"uri\":\"").append(jsonEscape(u))
                    .append("\",\"name\":\"").append(jsonEscape(folderDisplayName(uri)))
                    .append("\"}")
            }
            sb.append("]")
            return sb.toString()
        }

        @JavascriptInterface
        fun removeFolder(uriString: String) {
            val prefs = getSharedPreferences(STORAGE_PREFS, MODE_PRIVATE)
            val current = (prefs.getStringSet(KEY_FOLDER_URIS, null) ?: emptySet()).toMutableSet()
            current.remove(uriString)
            prefs.edit().putStringSet(KEY_FOLDER_URIS, current).apply()
            try {
                contentResolver.releasePersistableUriPermission(
                    Uri.parse(uriString),
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
                // Already released or never granted — safe to ignore.
            }
        }

        @JavascriptInterface
        fun hasAllFilesAccess(): Boolean = hasAllFilesAccessInternal()

        /** Whole-storage scan is available only while MANAGE_EXTERNAL_STORAGE is declared in the manifest. */
        @JavascriptInterface
        fun allFilesScanSupported(): Boolean =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.R || try {
                packageManager.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
                    .requestedPermissions?.contains(Manifest.permission.MANAGE_EXTERNAL_STORAGE) == true
            } catch (_: Exception) { false }

        @JavascriptInterface
        fun requestAllFilesAccess() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try {
                        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                            data = Uri.parse("package:$packageName")
                        }
                        allFilesAccessLauncher.launch(intent)
                    } catch (_: Exception) {
                        try {
                            allFilesAccessLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                        } catch (_: Exception) {
                            notifyAllFilesAccessChanged()
                        }
                    }
                } else {
                    legacyStoragePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
            }
        }

        /**
         * Finds every PDF already reachable on the device — from picked folders and, if granted,
         * the whole shared storage — WITHOUT copying any file. Returns a JSON array of
         * {key, name, size, lastModified, source}. "key" is later passed to readExternalChunk().
         */
        @JavascriptInterface
        fun scanForPdfs(): String {
            val out = StringBuilder("[")
            var first = true
            val emit: (String, String, Long, Long, String) -> Unit = { key, name, size, lastMod, source ->
                if (!first) out.append(",")
                first = false
                out.append("{\"key\":\"").append(jsonEscape(key))
                    .append("\",\"name\":\"").append(jsonEscape(name))
                    .append("\",\"size\":").append(size)
                    .append(",\"lastModified\":").append(lastMod)
                    .append(",\"source\":\"").append(source).append("\"}")
            }

            // 1) Folders the user explicitly picked (works on every Android version, minimal permission)
            val prefs = getSharedPreferences(STORAGE_PREFS, MODE_PRIVATE)
            val treeUris = prefs.getStringSet(KEY_FOLDER_URIS, null) ?: emptySet()
            val persisted = try {
                contentResolver.persistedUriPermissions
            } catch (_: Exception) {
                emptyList()
            }
            for (u in treeUris) {
                val treeUri = try {
                    Uri.parse(u)
                } catch (_: Exception) {
                    continue
                }
                if (persisted.none { it.uri == treeUri && it.isReadPermission }) continue
                try {
                    val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
                    scanTreeForPdfs(treeUri, rootDocId, 0, emit)
                } catch (_: Exception) {
                    // Skip this folder; never crash the whole scan for one bad entry.
                }
            }

            // 2) Whole-storage scan, only if the user granted "All files access"
            if (hasAllFilesAccessInternal()) {
                try {
                    var scanned = 0
                    fun walk(dir: File, depth: Int) {
                        if (depth > MAX_FOLDER_DEPTH || scanned >= MAX_TOTAL_ALL_FILES_SCAN) return
                        val path = dir.absolutePath
                        // Android 11+ still blocks other apps' private folders even with
                        // "All files access" — skip them so we don't waste time on errors.
                        if (path.endsWith("/Android/data") || path.endsWith("/Android/obb")) return
                        val children = try {
                            dir.listFiles()
                        } catch (_: Exception) {
                            null
                        } ?: return
                        for (f in children) {
                            if (scanned >= MAX_TOTAL_ALL_FILES_SCAN) return
                            scanned++
                            if (f.isDirectory) {
                                if (!f.name.startsWith(".")) walk(f, depth + 1)
                            } else if (f.name.endsWith(".pdf", ignoreCase = true)) {
                                emit(f.absolutePath, f.name, f.length(), f.lastModified(), "allfiles")
                            }
                        }
                    }
                    walk(Environment.getExternalStorageDirectory(), 0)
                } catch (_: Exception) {
                    // Never let a storage scan crash the app.
                }
            }

            out.append("]")
            return out.toString()
        }

        /**
         * Reads one chunk of an already-discovered PDF directly from its source
         * (content:// document or raw filesystem path) — the file is never duplicated
         * into app storage. Mirrors AndroidPdfBridge.readPdfChunk()'s chunking approach.
         */
        @JavascriptInterface
        fun readExternalChunk(key: String, offset: Int, length: Int): String? {
            return try {
                if (key.startsWith("content://")) {
                    val uri = Uri.parse(key)
                    contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                        FileInputStream(pfd.fileDescriptor).use { input ->
                            var skippedTotal = 0L
                            while (skippedTotal < offset) {
                                val skipped = input.skip((offset - skippedTotal))
                                if (skipped <= 0) break
                                skippedTotal += skipped
                            }
                            if (skippedTotal < offset) return null
                            val buffer = ByteArray(length)
                            val bytesRead = input.read(buffer)
                            if (bytesRead > 0) Base64.encodeToString(buffer, 0, bytesRead, Base64.NO_WRAP) else null
                        }
                    }
                } else {
                    val file = File(key)
                    if (!file.exists() || offset >= file.length() || offset < 0) return null
                    RandomAccessFile(file, "r").use { raf ->
                        raf.seek(offset.toLong())
                        val remaining = file.length() - offset
                        val toRead = if (remaining < length) remaining.toInt() else length
                        val buffer = ByteArray(toRead)
                        val bytesRead = raf.read(buffer)
                        if (bytesRead > 0) Base64.encodeToString(buffer, 0, bytesRead, Base64.NO_WRAP) else null
                    }
                }
            } catch (_: Exception) {
                null
            }
        }
    }
}
